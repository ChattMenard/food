/**
 * jest.setup.js
 * 
 * Global test setup - runs before each test file
 * Sets up mocks, polyfills, and global utilities
 */

import { jest } from '@jest/globals';
import 'fake-indexeddb/auto'; // Mock IndexedDB for tests

// ============================================================================
// GLOBAL MOCKS
// ============================================================================

// Mock localStorage
const localStorageMock = {
  getItem: jest.fn((key) => localStorageMock.store[key] || null),
  setItem: jest.fn((key, value) => { localStorageMock.store[key] = value; }),
  removeItem: jest.fn((key) => { delete localStorageMock.store[key]; }),
  clear: jest.fn(() => { localStorageMock.store = {}; }),
  store: {}
};

global.localStorage = localStorageMock;

// Mock sessionStorage
global.sessionStorage = { ...localStorageMock, store: {} };

// Mock navigator.onLine
Object.defineProperty(global.navigator, 'onLine', {
  writable: true,
  value: true
});

// Mock Service Worker
global.navigator.serviceWorker = {
  register: jest.fn(() => Promise.resolve()),
  ready: Promise.resolve({
    showNotification: jest.fn()
  })
};

// Mock Notification API
global.Notification = class Notification {
  constructor(title, options) {
    this.title = title;
    this.options = options;
  }
  
  static requestPermission() {
    return Promise.resolve('granted');
  }
  
  static permission = 'granted';
};

// Mock crypto.randomUUID (for device IDs)
if (!global.crypto) {
  global.crypto = {};
}
global.crypto.randomUUID = jest.fn(() => 
  'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  })
);

// Mock fetch (can be overridden in individual tests)
global.fetch = jest.fn(() =>
  Promise.resolve({
    ok: true,
    status: 200,
    json: () => Promise.resolve({}),
    text: () => Promise.resolve('')
  })
);

// Mock IntersectionObserver (for UI components)
global.IntersectionObserver = class IntersectionObserver {
  constructor() {}
  disconnect() {}
  observe() {}
  unobserve() {}
  takeRecords() { return []; }
};

// Mock ResizeObserver
global.ResizeObserver = class ResizeObserver {
  constructor() {}
  disconnect() {}
  observe() {}
  unobserve() {}
};

// Mock window.matchMedia (for responsive tests)
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(),
    removeListener: jest.fn(),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn()
  }))
});

// ============================================================================
// CUSTOM MATCHERS
// ============================================================================

expect.extend({
  // Custom matcher for checking IndexedDB keys
  toHaveIndexedDBKey(received, keyPath) {
    const pass = received && received[keyPath] !== undefined;
    return {
      pass,
      message: () => 
        pass
          ? `expected object not to have IndexedDB key ${keyPath}`
          : `expected object to have IndexedDB key ${keyPath}`
    };
  },
  
  // Custom matcher for date ranges
  toBeWithinRange(received, floor, ceiling) {
    const pass = received >= floor && received <= ceiling;
    return {
      pass,
      message: () =>
        pass
          ? `expected ${received} not to be within range ${floor} - ${ceiling}`
          : `expected ${received} to be within range ${floor} - ${ceiling}`
    };
  },
  
  // Custom matcher for array similarity (ignore order)
  toContainSameElements(received, expected) {
    const receivedSorted = [...received].sort();
    const expectedSorted = [...expected].sort();
    const pass = JSON.stringify(receivedSorted) === JSON.stringify(expectedSorted);
    
    return {
      pass,
      message: () =>
        pass
          ? `expected arrays not to contain same elements`
          : `expected ${JSON.stringify(received)} to contain same elements as ${JSON.stringify(expected)}`
    };
  }
});

// ============================================================================
// GLOBAL TEST UTILITIES
// ============================================================================

// Utility to wait for async operations
global.waitFor = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Utility to flush promises
global.flushPromises = () => new Promise(resolve => setImmediate(resolve));

// Utility to reset all mocks
global.resetAllMocks = () => {
  jest.clearAllMocks();
  localStorage.clear();
  sessionStorage.clear();
  fetch.mockClear();
};

// Utility to mock online/offline state
global.setOnlineStatus = (isOnline) => {
  Object.defineProperty(navigator, 'onLine', {
    writable: true,
    value: isOnline
  });
  
  if (isOnline) {
    window.dispatchEvent(new Event('online'));
  } else {
    window.dispatchEvent(new Event('offline'));
  }
};

// Utility to create mock IndexedDB transaction
global.createMockTransaction = () => ({
  objectStore: jest.fn(() => ({
    add: jest.fn(),
    put: jest.fn(),
    get: jest.fn(),
    delete: jest.fn(),
    getAll: jest.fn(),
    openCursor: jest.fn()
  })),
  oncomplete: null,
  onerror: null,
  onabort: null
});

// ============================================================================
// CONSOLE FILTERS (reduce noise in tests)
// ============================================================================

// Suppress expected console warnings/errors
const originalError = console.error;
const originalWarn = console.warn;

console.error = (...args) => {
  // Filter out expected errors
  const message = args[0];
  if (
    typeof message === 'string' &&
    (
      message.includes('Not implemented: navigation') || // jsdom limitation
      message.includes('Error: Not implemented: HTMLFormElement.prototype.submit') ||
      message.includes('IndexedDB') // Expected IDB errors in tests
    )
  ) {
    return;
  }
  originalError.call(console, ...args);
};

console.warn = (...args) => {
  // Filter out expected warnings
  const message = args[0];
  if (
    typeof message === 'string' &&
    message.includes('deprecated') // Deprecation warnings
  ) {
    return;
  }
  originalWarn.call(console, ...args);
};

// ============================================================================
// TEST LIFECYCLE HOOKS
// ============================================================================

// Before each test file
beforeAll(() => {
  // Set consistent timezone for date tests
  process.env.TZ = 'UTC';
});

// After each test
afterEach(() => {
  // Reset mocks
  jest.clearAllMocks();
  localStorage.clear();
  sessionStorage.clear();
  
  // Reset navigator.onLine
  Object.defineProperty(navigator, 'onLine', {
    writable: true,
    value: true
  });
});

// After all tests
afterAll(() => {
  // Cleanup
});

// ============================================================================
// PERFORMANCE MONITORING
// ============================================================================

// Track slow tests (> 1 second)
let testStartTime;

beforeEach(() => {
  testStartTime = Date.now();
});

afterEach(() => {
  const testDuration = Date.now() - testStartTime;
  if (testDuration > 1000) {
    console.warn(`⚠️ Slow test detected: ${testDuration}ms`);
  }
});
