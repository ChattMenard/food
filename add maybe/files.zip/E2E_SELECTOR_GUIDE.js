/**
 * E2E Selector Stability Guide
 * 
 * PROBLEM (from TODO): "E2E selector stability not guaranteed"
 * SOLUTION: Use data-testid attributes + Playwright best practices
 * 
 * This file shows how to fix your existing E2E tests.
 */

// ============================================================================
// BEFORE: Brittle Selectors (DON'T DO THIS)
// ============================================================================

// ❌ BAD - CSS classes can change with styling updates
await page.click('.pantry-add-button');
await page.click('.btn-primary.large');

// ❌ BAD - Text content is fragile (localization, copy changes)
await page.click('text=Add to Pantry');
await page.click('button:has-text("Submit")');

// ❌ BAD - DOM structure assumptions (changes break tests)
await page.click('div.container > form > button:nth-child(3)');
await page.click('main .card:first-child button');

// ❌ BAD - ID selectors when IDs might be dynamic
await page.click('#button-12345');


// ============================================================================
// AFTER: Stable Selectors (DO THIS)
// ============================================================================

// ✅ GOOD - data-testid attributes (never change, explicit test contract)
await page.click('[data-testid="pantry-add-button"]');
await page.click('[data-testid="meal-plan-save"]');

// ✅ GOOD - Playwright getByTestId helper (cleaner)
await page.getByTestId('pantry-add-button').click();
await page.getByTestId('meal-plan-save').click();

// ✅ GOOD - Role-based selectors (accessibility + stability)
await page.getByRole('button', { name: 'Add to Pantry' }).click();
await page.getByRole('textbox', { name: 'Ingredient name' }).fill('Pasta');

// ✅ GOOD - Label associations (semantic HTML)
await page.getByLabel('Quantity').fill('2');
await page.getByLabel('Unit').selectOption('lbs');


// ============================================================================
// IMPLEMENTATION: Adding data-testid to Your HTML
// ============================================================================

/**
 * PANTRY PAGE EXAMPLE
 * 
 * Before:
 * <button class="btn btn-primary" onclick="addPantryItem()">
 *   Add to Pantry
 * </button>
 * 
 * After:
 * <button 
 *   class="btn btn-primary" 
 *   data-testid="pantry-add-button"
 *   onclick="addPantryItem()"
 * >
 *   Add to Pantry
 * </button>
 */

// Convention: Use kebab-case, describe WHAT it does, not HOW it looks
// ✅ pantry-add-button (clear, semantic)
// ❌ blue-button-large (styling details)
// ❌ btn-1 (meaningless ID)


// ============================================================================
// UPDATED E2E TEST EXAMPLES
// ============================================================================

import { test, expect } from '@playwright/test';

// PANTRY E2E TEST (REFACTORED)
test.describe('Pantry Management', () => {
  
  test.beforeEach(async ({ page }) => {
    await page.goto('http://localhost:8080');
    // Wait for app to be fully loaded
    await page.waitForSelector('[data-testid="app-loaded"]', { timeout: 5000 });
  });

  test('should add ingredient to pantry', async ({ page }) => {
    // Navigate to pantry
    await page.getByTestId('nav-pantry').click();
    
    // Fill ingredient form using stable selectors
    await page.getByTestId('ingredient-name-input').fill('Pasta');
    await page.getByTestId('ingredient-quantity-input').fill('2');
    await page.getByTestId('ingredient-unit-select').selectOption('lb');
    
    // Submit
    await page.getByTestId('pantry-add-button').click();
    
    // Verify item appears in list
    const pantryList = page.getByTestId('pantry-item-list');
    await expect(pantryList).toContainText('Pasta');
    await expect(pantryList).toContainText('2 lb');
  });

  test('should handle offline ingredient addition', async ({ page, context }) => {
    // Go offline
    await context.setOffline(true);
    
    // Add ingredient while offline
    await page.getByTestId('nav-pantry').click();
    await page.getByTestId('ingredient-name-input').fill('Rice');
    await page.getByTestId('ingredient-quantity-input').fill('5');
    await page.getByTestId('pantry-add-button').click();
    
    // Should show offline indicator
    await expect(page.getByTestId('offline-banner')).toBeVisible();
    
    // Item should still appear in list (local state)
    await expect(page.getByTestId('pantry-item-list')).toContainText('Rice');
    
    // Go back online
    await context.setOffline(false);
    
    // Wait for sync
    await page.waitForSelector('[data-testid="sync-complete"]', { timeout: 10000 });
    
    // Reload page - item should persist
    await page.reload();
    await expect(page.getByTestId('pantry-item-list')).toContainText('Rice');
  });

  test('should delete ingredient from pantry', async ({ page }) => {
    // Add item first
    await page.getByTestId('nav-pantry').click();
    await page.getByTestId('ingredient-name-input').fill('Tomatoes');
    await page.getByTestId('pantry-add-button').click();
    
    // Find and delete the item
    const itemRow = page.getByTestId('pantry-item-tomatoes'); // Convention: pantry-item-{name}
    await itemRow.getByTestId('delete-button').click();
    
    // Confirm deletion modal
    await page.getByTestId('confirm-delete-modal').getByRole('button', { name: 'Confirm' }).click();
    
    // Verify item removed
    await expect(page.getByTestId('pantry-item-list')).not.toContainText('Tomatoes');
  });
});

// MEAL PLANNING E2E TEST (REFACTORED)
test.describe('Meal Planning', () => {
  
  test('should generate AI meal suggestions', async ({ page }) => {
    // Navigate to meals
    await page.getByTestId('nav-meals').click();
    
    // Click AI suggestion button
    await page.getByTestId('ai-suggest-button').click();
    
    // Wait for AI response (with timeout)
    await page.waitForSelector('[data-testid="suggestion-card"]', { timeout: 15000 });
    
    // Verify suggestions loaded
    const suggestions = page.getByTestId('suggestions-container');
    const cards = await suggestions.getByTestId('suggestion-card').count();
    expect(cards).toBeGreaterThan(0);
  });

  test('should fall back to local suggestions when offline', async ({ page, context }) => {
    await context.setOffline(true);
    
    await page.getByTestId('nav-meals').click();
    await page.getByTestId('ai-suggest-button').click();
    
    // Should show fallback message
    await expect(page.getByTestId('offline-fallback-message')).toBeVisible();
    
    // Should still show local suggestions
    await expect(page.getByTestId('suggestion-card')).toHaveCount(3, { timeout: 5000 });
  });
});


// ============================================================================
// PLAYWRIGHT CONFIGURATION (playwright.config.js)
// ============================================================================

export default {
  testDir: './e2e',
  timeout: 30000,
  expect: {
    timeout: 5000
  },
  fullyParallel: true,
  retries: process.env.CI ? 2 : 0, // Retry flaky tests in CI
  workers: process.env.CI ? 1 : undefined,
  
  use: {
    baseURL: 'http://localhost:8080',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    
    // IMPORTANT: Auto-wait for elements
    actionTimeout: 10000,
    navigationTimeout: 30000
  },
  
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] }
    },
    {
      name: 'mobile',
      use: { ...devices['Pixel 5'] }
    }
  ],
  
  webServer: {
    command: 'npm run serve:test',
    port: 8080,
    timeout: 120000,
    reuseExistingServer: !process.env.CI
  }
};


// ============================================================================
// HTML ATTRIBUTE NAMING CONVENTIONS
// ============================================================================

/**
 * Navigation: nav-{page}
 * Example: data-testid="nav-pantry", "nav-meals", "nav-plan"
 * 
 * Buttons: {action}-button
 * Example: "add-button", "save-button", "delete-button"
 * 
 * Form Inputs: {field}-input
 * Example: "ingredient-name-input", "quantity-input"
 * 
 * Lists: {type}-list
 * Example: "pantry-item-list", "recipe-list"
 * 
 * List Items: {type}-item-{id}
 * Example: "pantry-item-pasta", "recipe-item-12345"
 * 
 * Containers: {section}-container
 * Example: "suggestions-container", "meal-plan-container"
 * 
 * Status Indicators: {status}-banner / {status}-message
 * Example: "offline-banner", "sync-complete", "error-message"
 */


// ============================================================================
// MIGRATION CHECKLIST
// ============================================================================

/**
 * 1. [ ] Add data-testid to all interactive elements (buttons, inputs, links)
 * 2. [ ] Add data-testid to all containers that tests query
 * 3. [ ] Add app-loaded indicator for test readiness
 * 4. [ ] Update all existing E2E tests to use getByTestId()
 * 5. [ ] Run tests 3x consecutively - must pass all times
 * 6. [ ] Remove old CSS/text selectors
 * 7. [ ] Document data-testid conventions in team wiki
 */
