/**
 * jest.config.js
 * 
 * Jest configuration with ENFORCED coverage thresholds
 * Based on TODO Phase A4 requirements:
 * - Statements: 80%
 * - Branches: 70%
 * - Functions: 80%
 * - Lines: 80%
 */

export default {
  // Test environment
  testEnvironment: 'jsdom',
  
  // Root directory
  rootDir: '.',
  
  // Test file patterns
  testMatch: [
    '**/__tests__/**/*.test.js',
    '**/?(*.)+(spec|test).js'
  ],
  
  // Files to ignore
  testPathIgnorePatterns: [
    '/node_modules/',
    '/www/dist/',
    '/platforms/',
    '/e2e/' // E2E tests run separately via Playwright
  ],
  
  // Module paths
  moduleDirectories: ['node_modules', 'www/js'],
  
  // Module name mapper for path aliases
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/www/js/$1',
    '^@core/(.*)$': '<rootDir>/www/js/core/$1',
    '^@data/(.*)$': '<rootDir>/www/js/data/$1',
    '^@logic/(.*)$': '<rootDir>/www/js/logic/$1',
    '^@features/(.*)$': '<rootDir>/www/js/features/$1',
    '^@ai/(.*)$': '<rootDir>/www/js/ai/$1',
    '^@ui/(.*)$': '<rootDir>/www/js/ui/$1',
    '^@utils/(.*)$': '<rootDir>/www/js/utils/$1',
    '^@native/(.*)$': '<rootDir>/www/js/native/$1',
    '^@auth/(.*)$': '<rootDir>/www/js/auth/$1',
    '^@advanced/(.*)$': '<rootDir>/www/js/advanced/$1'
  },
  
  // Setup files
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
  
  // Transform files (if using TypeScript or JSX)
  transform: {
    '^.+\\.jsx?$': 'babel-jest'
  },
  
  // Coverage configuration
  collectCoverageFrom: [
    'www/js/**/*.js',
    '!www/js/**/*.test.js',
    '!www/js/**/__tests__/**',
    '!www/js/config.js', // Config doesn't need coverage
    '!www/js/main.js', // Entry point
    '!**/node_modules/**',
    '!**/dist/**',
    '!**/platforms/**'
  ],
  
  // CRITICAL: Coverage thresholds (from TODO Phase A4)
  // Build FAILS if coverage drops below these
  coverageThreshold: {
    global: {
      statements: 80,
      branches: 70,
      functions: 80,
      lines: 80
    },
    // Stricter thresholds for critical modules
    './www/js/core/**/*.js': {
      statements: 90,
      branches: 80,
      functions: 90,
      lines: 90
    },
    './www/js/data/**/*.js': {
      statements: 85,
      branches: 75,
      functions: 85,
      lines: 85
    },
    './www/js/logic/**/*.js': {
      statements: 90,
      branches: 80,
      functions: 90,
      lines: 90
    }
  },
  
  // Coverage reporters
  coverageReporters: [
    'text',           // Console output
    'text-summary',   // Brief summary
    'html',           // HTML report (coverage/index.html)
    'lcov',           // For CI tools (Codecov, Coveralls)
    'json-summary'    // For coverage diff in CI
  ],
  
  // Coverage directory
  coverageDirectory: 'coverage',
  
  // Clear mocks between tests
  clearMocks: true,
  
  // Restore mocks between tests
  restoreMocks: true,
  
  // Verbose output
  verbose: true,
  
  // Timeouts
  testTimeout: 10000, // 10 seconds per test
  
  // Global setup/teardown
  // globalSetup: '<rootDir>/jest.global-setup.js',
  // globalTeardown: '<rootDir>/jest.global-teardown.js',
  
  // Detect open handles (useful for debugging async issues)
  detectOpenHandles: true,
  
  // Force exit after tests complete (if needed)
  forceExit: false,
  
  // Max workers (parallel execution)
  maxWorkers: '50%' // Use half of available CPUs
};


/**
 * USAGE:
 * 
 * Run all tests:
 * npm test
 * 
 * Run with coverage:
 * npm run test:coverage
 * 
 * Run specific test file:
 * npm test -- recipeEngine.test.js
 * 
 * Run in watch mode:
 * npm test -- --watch
 * 
 * Update snapshots:
 * npm test -- -u
 * 
 * Coverage report location:
 * coverage/index.html (open in browser)
 */
